import { Component } from '@angular/core';
import {Subscription} from "rxjs";
// import {EditService} from "./app.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  dataTableSubscription: Subscription | undefined;
  limit = 10;
  offset = 10;
  inputFieldValue: any;
  Description:any;
  status:any;
  datetime:any;
  tableData: any[] = [];
  f: any;
  editmode = false;
  editText = '';
  text: any;


  // constructor(public editService:EditService) {}

  ngOnInit() {
    this.getData();
  }

  addData(){
    this.tableData.push(this.inputFieldValue);
    this.tableData.push(this.Description);
    this.tableData.push(this.status);
    this.tableData.push(this.datetime);
    this.editmode = false;
    this.text = this.editText;
    // this.editService.save('text', this.editText);
  }

  getData(){
    let sample_data: any[] = [];
    this.loadData(sample_data);

  }
  loadData(data: any[]){
    this.tableData = [...this.tableData, ...data];
  }

  handleError(error: any){
    console.log(error);
  }

  edit() {
    this.editmode = true;
    this.editText = this.text;
  }

}
